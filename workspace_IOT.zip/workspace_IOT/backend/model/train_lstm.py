# Updated and fixed LSTM model training code
# backend/model/train_lstm.py
import os
os.environ['TF_ENABLE_ONEDNN_OPTS'] = '0'

import pandas as pd
import numpy as np
import os
import joblib
from sklearn.preprocessing import MinMaxScaler
from keras.models import Sequential
from keras.layers import LSTM, Dense, Input
import json

os.environ['TF_ENABLE_ONEDNN_OPTS'] = '0'

# Dynamic base path resolution
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_PATH = os.path.join(BASE_DIR, "..", "data", "Rain_data.csv")
MODEL_DIR = os.path.join(BASE_DIR, "..", "model")
OUTPUT_JSON = os.path.join(BASE_DIR, "..", "data", "map_data.json")

# Load dataset
df = pd.read_csv(DATA_PATH)
df["SUBDIVISION"] = df["SUBDIVISION"].str.strip().str.upper()

# List to collect prediction output
to_json = []

# Create model output dir
os.makedirs(MODEL_DIR, exist_ok=True)

# Unique subdivisions
subdivisions = df["SUBDIVISION"].unique()

for subdivision in subdivisions:
    data = df[df["SUBDIVISION"] == subdivision][["YEAR", "ANNUAL", "Latitude", "Longitude"]].sort_values("YEAR")

    if len(data) < 6:
        continue  # Skip if insufficient data

    scaler = MinMaxScaler()
    scaled_rain = scaler.fit_transform(data["ANNUAL"].values.reshape(-1, 1))

    # Sequence generation
    def create_sequences(data, seq_len=5):
        X, y = [], []
        for i in range(len(data) - seq_len):
            X.append(data[i:i+seq_len])
            y.append(data[i+seq_len])
        return np.array(X), np.array(y)

    X, y = create_sequences(scaled_rain)
    X = X.reshape((X.shape[0], X.shape[1], 1))

    # Define and train LSTM
    model = Sequential([
        Input(shape=(X.shape[1], 1)),
        LSTM(50, activation='relu'),
        Dense(1)
    ])
    model.compile(optimizer='adam', loss='mse')
    model.fit(X, y, epochs=50, verbose=0)

    # Save model & scaler
    model_name = subdivision.replace(' ', '_')
    model.save(os.path.join(MODEL_DIR, f"{model_name}_lstm.keras"))
    joblib.dump(scaler, os.path.join(MODEL_DIR, f"{model_name}_scaler.pkl"))

    # Predict next value
    last_sequence = scaled_rain[-5:].reshape(1, 5, 1)
    predicted_scaled = model.predict(last_sequence)
    predicted = float(scaler.inverse_transform(predicted_scaled)[0][0])

    # Save prediction to JSON-like dict
    to_json.append({
        "subdivision": subdivision.title(),
        "latitude": float(data["Latitude"].iloc[0]),
        "longitude": float(data["Longitude"].iloc[0]),
        "predicted_rainfall": round(predicted, 2)
    })

# Save map JSON
with open(OUTPUT_JSON, "w") as f:
    json.dump(to_json, f, indent=2)

print("✅ All subdivision models trained and predictions saved to map_data.json")
